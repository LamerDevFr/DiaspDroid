package fr.android.scaron.diaspdroid.model;

/**
 * Created by Sébastien on 06/03/2015.
 */
public class ItemDrawer {

    public final String itemName;

    public ItemDrawer(String itemName) {
        this.itemName = itemName;
    }
}
