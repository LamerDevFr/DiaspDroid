package fr.android.scaron.diaspdroid.vues.fragment;

import com.google.android.youtube.player.YouTubePlayerSupportFragment;
/**
 * Created by Sébastien on 04/02/2015.
 */
public class YoutubePlayerFragment extends YouTubePlayerSupportFragment {

}
