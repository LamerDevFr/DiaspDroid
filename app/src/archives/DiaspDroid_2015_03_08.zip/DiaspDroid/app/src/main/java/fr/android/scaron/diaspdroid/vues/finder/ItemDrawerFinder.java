package fr.android.scaron.diaspdroid.vues.finder;

import java.util.List;

import fr.android.scaron.diaspdroid.model.ItemDrawer;

/**
 * Created by Sébastien on 06/03/2015.
 */
public interface ItemDrawerFinder {
    List<ItemDrawer> findAll();
}