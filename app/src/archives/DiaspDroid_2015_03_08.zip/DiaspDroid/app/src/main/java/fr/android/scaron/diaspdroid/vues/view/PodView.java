package fr.android.scaron.diaspdroid.vues.view;

import android.support.v4.app.Fragment;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;

/**
 * Created by Sébastien on 20/02/2015.
 */
public class PodView extends Fragment {

    public TextView text = null;
    public CheckBox check = null;
//    public RadioButton check = null;

}
