package fr.android.scaron.diaspdroid;

/**
 * Created by Sébastien on 30/01/2015.
 */
public class DeveloperKey {
    public static final String DEVELOPER_KEY = "AIzaSyDOvTXMhTpC9SUNO4pS0-3k-TQyTTKd448";
}
