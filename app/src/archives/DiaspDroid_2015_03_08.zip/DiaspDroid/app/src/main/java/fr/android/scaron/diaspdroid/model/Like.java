package fr.android.scaron.diaspdroid.model;

/**
 * Created by Maison on 13/01/2015.
 */
public class Like {
}
