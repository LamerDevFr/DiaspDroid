package fr.android.scaron.diaspdroid.model;

/**
 * Created by Maison on 12/01/2015.
 */
public class OEmbedCache {
    Data data;

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }
}
