package fr.android.scaron.diaspdroid.model;

/**
 * Created by Sébastien on 16/01/2015.
 */
public class Constant {

    public static String DATETIME_PATTERN = "d MMM yyyy HH:mm";
}
