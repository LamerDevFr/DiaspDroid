package fr.android.scaron.diaspdroid.model;

/**
 * Created by Sébastien on 18/01/2015.
 */
public class UploadData {
    public UploadPhoto getPhoto() {
        return photo;
    }

    public void setPhoto(UploadPhoto photo) {
        this.photo = photo;
    }

    UploadPhoto photo;
}
