package fr.android.scaron.diaspdroid.model;

/**
 * Created by Maison on 13/01/2015.
 */
public class Dimension {
//    "dimensions": {
//                "height": 2401,
    Integer height;
//                "width": 3608
    Integer width;
//        }


    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }
}
