package fr.android.scaron.diaspdroid.model;

import android.app.Application;
import android.content.Context;

import com.google.gson.Gson;

import fr.android.scaron.diaspdroid.controler.CookieControler;
import fr.android.scaron.diaspdroid.controler.DiasporaControler;

/**
 * Created by Sébastien on 22/02/2015.
 */
public class DiasporaConfig {

    public static String POD_USER;
    public static String POD_PASSWORD;
    public static String POD_URL;
    public static String POD_LIST_JSON;
    public static Pods POD_LIST;

    public static Application APPLICATION;
    public static Context APPLICATION_CONTEXT;
    public static TinyDB DB;

    public static void init(final Application pApplication, final Context pApplicationContext){
        // Chargement de la configuration sauvegardée
        APPLICATION = pApplication;
        APPLICATION_CONTEXT = pApplicationContext;
        DB = new TinyDB(pApplicationContext);
        final String user=DiasporaConfig.DB.getString("diaspora_user");
        final String password=DiasporaConfig.DB.getString("diaspora_password");
        final String url=DiasporaConfig.DB.getString("diaspora_pod");
        final String podlistJson=DiasporaConfig.DB.getString("diaspora_podlist");

        if (user!=null && !user.isEmpty()){
            POD_USER = user;
        }
        if (password!=null && !password.isEmpty()){
            POD_PASSWORD = password;
        }
        if (url!=null && !url.isEmpty()){
            POD_URL = url;
        }
        if (podlistJson!=null && !podlistJson.isEmpty()){
            POD_LIST = new Gson().fromJson(podlistJson, Pods.class);
            POD_LIST_JSON = podlistJson;
        }
        DiasporaControler.initParams();
        CookieControler.init();
    }

    public static void setPods(final Pods pPods){

        if (pPods!=null && pPods.getPodcount()>0 && pPods.getPods()!=null && !pPods.getPods().isEmpty()) {
            POD_LIST = pPods;
            POD_LIST_JSON = new Gson().toJson(pPods);
        }
    }

    public static void setPodAuthenticationValues(final String pPodUrl, final String pPodUser, final String pPodPassword){
        DB.putString("diaspora_user", pPodUser);
        DB.putString("diaspora_password", pPodPassword);
        DB.putString("diaspora_pod", pPodUrl);
        POD_URL = pPodUrl;
        POD_USER = pPodUser;
        POD_PASSWORD = pPodPassword;
        DiasporaControler.initParams();
    }

    public static boolean isValid(){
        if (POD_URL==null || POD_USER==null || POD_PASSWORD==null
                ||POD_URL.isEmpty() || POD_USER.isEmpty() || POD_PASSWORD.isEmpty()){
            return false;
        }
        return true;
    }
}
